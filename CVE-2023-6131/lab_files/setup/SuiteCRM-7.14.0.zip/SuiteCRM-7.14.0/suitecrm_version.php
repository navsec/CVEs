<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version = '7.14.0';
$suitecrm_timestamp = '2023-08-29 12:00:00';
